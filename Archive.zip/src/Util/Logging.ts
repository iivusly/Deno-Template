import * as Colors from 'fmt/colors.ts'

enum Type {
	ERROR = "ERROR",
	WARNING = "WARNING",
	LOG = "LOG"
}

class Logger {
    private format(
        Color: (str: string) => string,
        LogType: Type,
        Input: string
    ): string {
        const date_ob = new Date()

		return `${date_ob.getHours()}:${date_ob.getMinutes()}:${date_ob.getSeconds()} ${Color(
            `[${LogType}]`
        )} ${Input}`
    }

	Log(str: string) {
		return console.log(this.format(Colors.blue, Type.LOG, str))
	}

	Error(str: string) {
		return console.log(this.format(Colors.red, Type.ERROR, str))
	}

	Warn(str: string) {
		return console.log(this.format(Colors.yellow, Type.WARNING, str))
	}
}

export default new Logger()