const Resolvers = { Query: { hello: () => `Hello World!` } }

export default Resolvers
