import { Server } from 'http/server.ts'

import { GraphQLHTTP } from 'gql'
import { makeExecutableSchema } from 'graphql_tools'
import {gql} from 'graphql_tag'

import resolvers from './Resolvers.ts'

const App = new Server({
    handler: async (req) => {
        const { pathname } = new URL(req.url)
        return pathname === '/graphql'
            ? await GraphQLHTTP<Request>({
                  schema: makeExecutableSchema({
                      resolvers,
                      typeDefs: gql(Deno.readTextFileSync('./src/GraphQL/Query.graphql'))
                  }),
                  graphiql: true
              })(req)
            : new Response('Not Found', { status: 404 })
    },
    port: 3000
})

export default function Run() {
    return App.listenAndServe()
}
