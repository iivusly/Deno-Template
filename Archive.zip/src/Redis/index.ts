import { connect } from 'redis'

const Redis = await connect({
    hostname: '127.0.0.1',
    port: 6379,
    password: Deno.env.get('PASSWORD')
})

function CheckConnection() {
    return Redis.ping()
}

export default Redis
export { CheckConnection }
