import GQL from './GraphQL/index.ts'
import { CheckConnection } from './Redis/index.ts'
import Logger from './Util/Logging.ts'

async function init() {
	Logger.Log(`Ping from Redis Database recieved ${await CheckConnection()}`)
	await GQL()
}

await init()


/*	Usage:
Startup - deno run --import-map ./import_map.json --allow-net --allow-env --allow-read ./src/main.ts


*/